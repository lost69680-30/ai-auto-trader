#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python -m pytest backend/tests -q
python -m compileall -q backend
test -f android/settings.gradle.kts
test -f android/app/build.gradle.kts
test -f android/app/src/main/AndroidManifest.xml
grep -q 'LIVE_TRADING_ENABLED=false' .env.example
grep -q 'APP_ENV=testnet' .env.example
printf 'Backend tests, backend compilation, Android structure, and safe defaults verified.\n'
