# AI Auto Trader

Analysis-first autonomous trading platform for crypto, with Binance Spot Testnet as the initial execution adapter and a future broker-adapter boundary for forex.

## Design principle

**Market data → analysis → risk assessment → opportunity detection → decision → execution → outcome analysis**

Trading is downstream of evidence. `NO_TRADE` is a first-class decision.

## Project layout

- `backend/` — FastAPI API, market intelligence, strategy, risk, execution, Binance adapter, persistence
- `android/` — Kotlin/Jetpack Compose control app
- `.github/workflows/` — backend tests, Android build, security defaults
- `docs/` — architecture, plan, and runbook

## Safety

The shipped configuration is Testnet-first and live trading is disabled by default. Exchange secrets remain server-side.
