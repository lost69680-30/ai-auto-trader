from __future__ import annotations

import os

from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker


class Base(DeclarativeBase):
    pass


DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ai_auto_trader.db")
_engine_args = {"connect_args": {"check_same_thread": False}} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, future=True, **_engine_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def session() -> Session:
    return SessionLocal()
