from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Candle:
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float

    def __post_init__(self) -> None:
        if self.high < max(self.open, self.close) or self.low > min(self.open, self.close):
            raise ValueError("Candle high/low must contain open and close")
        if self.high < self.low:
            raise ValueError("Candle high must be >= low")
        if self.volume < 0:
            raise ValueError("Candle volume must be non-negative")


@dataclass(frozen=True)
class MarketAssessment:
    timeframe: str
    regime: str
    features: dict[str, float | str]
    risk_factors: dict[str, float | str]
    data_quality: str
    opportunity_state: str
    reason_codes: tuple[str, ...]
