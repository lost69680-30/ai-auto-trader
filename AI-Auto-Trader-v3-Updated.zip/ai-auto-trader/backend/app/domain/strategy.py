from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StrategySignal:
    side: str
    confidence: float
    reason_codes: tuple[str, ...]
    stop_distance: float | None
    take_profit_distance: float | None
    expiry_candles: int = 1
