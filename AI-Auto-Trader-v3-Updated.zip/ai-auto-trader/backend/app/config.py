from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Settings:
    environment: str = os.getenv("APP_ENV", "testnet")
    live_enabled: bool = os.getenv("LIVE_TRADING_ENABLED", "false").lower() == "true"
    binance_testnet_base_url: str = os.getenv("BINANCE_TESTNET_BASE_URL", "https://testnet.binance.vision")
    binance_api_key: str | None = field(default_factory=lambda: os.getenv("BINANCE_API_KEY"), repr=False)
    binance_api_secret: str | None = field(default_factory=lambda: os.getenv("BINANCE_API_SECRET"), repr=False)
    oanda_practice_base_url: str = os.getenv("OANDA_PRACTICE_BASE_URL", "https://api-fxpractice.oanda.com")
    oanda_account_id: str | None = field(default_factory=lambda: os.getenv("OANDA_ACCOUNT_ID"))
    oanda_api_token: str | None = field(default_factory=lambda: os.getenv("OANDA_API_TOKEN"), repr=False)
    openai_api_key: str | None = field(default_factory=lambda: os.getenv("OPENAI_API_KEY"), repr=False)
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-6-astra")

    def __post_init__(self) -> None:
        if self.environment != "testnet" and not self.live_enabled:
            raise ValueError("Non-testnet environment requires LIVE_TRADING_ENABLED=true")
