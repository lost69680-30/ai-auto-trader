from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from backend.app.domain.market import Candle
from backend.app.domain.strategy import StrategySignal


@dataclass(frozen=True)
class BacktestCosts:
    fee_bps: float = 5.0
    slippage_bps: float = 2.0


@dataclass(frozen=True)
class BacktestResult:
    initial_equity: float
    final_equity: float
    net_pnl: float
    total_fees: float
    trade_count: int


def _cost(notional: float, costs: BacktestCosts) -> float:
    return notional * (costs.fee_bps + costs.slippage_bps) / 10_000


def backtest(
    strategy: Callable[[list[Candle], str], StrategySignal],
    candles: list[Candle],
    *,
    initial_equity: float,
    costs: BacktestCosts,
    timeframe: str = "15m",
) -> BacktestResult:
    equity = initial_equity
    fees = 0.0
    trades = 0
    for i in range(5, len(candles) - 1):
        signal = strategy(candles[: i + 1], timeframe)
        if signal.side == "NONE":
            continue
        entry = candles[i + 1].open
        exit_price = candles[i + 1].close
        notional = max(1.0, equity * 0.01)
        signed_return = (exit_price - entry) / entry
        if signal.side == "SHORT":
            signed_return *= -1
        gross = notional * signed_return
        trade_cost = _cost(notional, costs)
        fees += trade_cost
        equity += gross - trade_cost
        trades += 1
    return BacktestResult(initial_equity, equity, equity - initial_equity, fees, trades)
