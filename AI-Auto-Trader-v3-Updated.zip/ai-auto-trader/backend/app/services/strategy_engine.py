from __future__ import annotations

from backend.app.domain.market import Candle, MarketAssessment
from backend.app.domain.strategy import StrategySignal
from backend.app.services.market_analysis import analyze_market


def evaluate_strategy(assessment: MarketAssessment) -> StrategySignal:
    if assessment.opportunity_state not in {"CANDIDATE", "APPROVED"}:
        return StrategySignal("NONE", 0.0, assessment.reason_codes + ("NO_QUALIFIED_OPPORTUNITY",), None, None)
    trend = assessment.features.get("trend")
    momentum = float(assessment.features.get("momentum", 0.0))
    atr = float(assessment.features.get("atr", 0.0))
    if atr <= 0:
        return StrategySignal("NONE", 0.0, assessment.reason_codes + ("INVALID_ATR",), None, None)
    side = "LONG" if trend == "BULLISH" and momentum > 0 else "SHORT" if trend == "BEARISH" and momentum < 0 else "NONE"
    if side == "NONE":
        return StrategySignal("NONE", 0.0, assessment.reason_codes + ("DIRECTION_NOT_CONFIRMED",), None, None)
    confidence = min(0.95, 0.5 + abs(momentum) * 10 + min(0.2, float(assessment.features.get("relative_volume", 1.0)) * 0.05))
    return StrategySignal(side, confidence, assessment.reason_codes, atr, atr * 2.0)


def baseline_strategy(candles: list[Candle], timeframe: str) -> StrategySignal:
    return evaluate_strategy(analyze_market(candles, timeframe))
