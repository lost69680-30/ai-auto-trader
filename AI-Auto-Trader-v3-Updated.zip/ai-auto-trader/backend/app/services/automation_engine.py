from __future__ import annotations

from dataclasses import dataclass
from uuid import uuid4

from backend.app.domain.strategy import StrategySignal
from backend.app.services.execution import ExecutionIntent, ExecutionService
from backend.app.services.market_intelligence import analyze_symbol
from backend.app.services.risk_engine import RiskEngine
from backend.app.services.strategy_engine import evaluate_strategy


@dataclass(frozen=True)
class AccountSnapshot:
    equity: float
    daily_realized_loss: float
    drawdown: float
    open_positions: int


@dataclass(frozen=True)
class AutomationResult:
    status: str
    reasons: tuple[str, ...] = ()
    risk_amount: float = 0.0
    quantity: float = 0.0
    client_order_id: str | None = None


class AutomationEngine:
    def __init__(self, adapter, execution: ExecutionService, risk_engine: RiskEngine) -> None:
        self.adapter = adapter
        self.execution = execution
        self.risk_engine = risk_engine

    def run_cycle(self, symbol: str, account: AccountSnapshot, *, emergency_stop: bool) -> AutomationResult:
        intelligence = analyze_symbol(self.adapter, symbol, ["15m"])
        assessment = intelligence.timeframes.get("15m")
        if assessment is None:
            return AutomationResult("BLOCKED", ("NO_ANALYSIS",))
        signal: StrategySignal = evaluate_strategy(assessment)
        decision = self.risk_engine.approve(
            signal,
            assessment,
            equity=account.equity,
            daily_realized_loss=account.daily_realized_loss,
            drawdown=account.drawdown,
            open_positions=account.open_positions,
            emergency_stop=emergency_stop,
        )
        if not decision.approved:
            return AutomationResult("BLOCKED", decision.reasons, decision.risk_amount, decision.quantity)

        entry = float(assessment.features["last_close"])
        if signal.side == "LONG":
            side = "BUY"
            stop = entry - float(signal.stop_distance)
            take_profit = entry + float(signal.take_profit_distance)
        else:
            side = "SELL"
            stop = entry + float(signal.stop_distance)
            take_profit = entry - float(signal.take_profit_distance)
        client_order_id = f"AIAT-{uuid4().hex[:20]}"
        intent = ExecutionIntent(client_order_id, symbol.upper(), side, decision.quantity, stop, take_profit)
        result = self.execution.submit(intent)
        return AutomationResult("EXECUTED", (), decision.risk_amount, decision.quantity, client_order_id)
