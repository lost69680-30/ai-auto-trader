from __future__ import annotations

from dataclasses import dataclass

from backend.app.domain.market import MarketAssessment
from backend.app.domain.strategy import StrategySignal


@dataclass(frozen=True)
class RiskPolicy:
    risk_per_trade: float = 0.005
    max_open_positions: int = 3
    max_daily_loss: float = 0.02
    max_drawdown: float = 0.05


@dataclass(frozen=True)
class RiskDecision:
    approved: bool
    reasons: tuple[str, ...]
    quantity: float
    risk_amount: float


class RiskEngine:
    def __init__(self, policy: RiskPolicy | None = None) -> None:
        self.policy = policy or RiskPolicy()

    def approve(
        self,
        signal: StrategySignal,
        assessment: MarketAssessment,
        *,
        equity: float,
        daily_realized_loss: float,
        drawdown: float,
        open_positions: int,
        emergency_stop: bool,
    ) -> RiskDecision:
        reasons: list[str] = []
        if emergency_stop:
            reasons.append("EMERGENCY_STOP")
        if signal.side == "NONE":
            reasons.append("NO_SIGNAL")
        if signal.stop_distance is None or signal.take_profit_distance is None:
            reasons.append("PROTECTED_EXIT_REQUIRED")
        if assessment.data_quality != "GOOD":
            reasons.append("BAD_DATA_QUALITY")
        if open_positions >= self.policy.max_open_positions:
            reasons.append("MAX_OPEN_POSITIONS")
        if drawdown >= self.policy.max_drawdown:
            reasons.append("MAX_DRAWDOWN")
        if equity > 0 and abs(min(0.0, daily_realized_loss)) / equity >= self.policy.max_daily_loss:
            reasons.append("MAX_DAILY_LOSS")
        risk_amount = max(0.0, equity * self.policy.risk_per_trade)
        quantity = risk_amount / signal.stop_distance if signal.stop_distance and signal.stop_distance > 0 else 0.0
        approved = not reasons and quantity > 0
        return RiskDecision(approved, tuple(dict.fromkeys(reasons)), quantity, risk_amount)
