from __future__ import annotations

from dataclasses import dataclass

from backend.app.domain.market import MarketAssessment


@dataclass(frozen=True)
class RiskPolicy:
    max_drawdown: float = 0.05
    max_daily_loss: float = 0.02
    max_open_positions: int = 3
    max_spread_bps: float = 10.0


@dataclass(frozen=True)
class RiskAssessment:
    approved: bool
    risk_level: str
    reasons: tuple[str, ...]
    score: float


def assess_risk(
    market: MarketAssessment,
    *,
    equity: float,
    daily_realized_loss: float,
    current_drawdown: float,
    open_positions: int,
    spread_bps: float,
    policy: RiskPolicy | None = None,
) -> RiskAssessment:
    p = policy or RiskPolicy()
    reasons = list(market.reason_codes)
    if market.data_quality != "GOOD":
        reasons.append("INSUFFICIENT_DATA" if market.data_quality == "INSUFFICIENT" else "BAD_DATA_QUALITY")
    volatility = float(market.risk_factors.get("volatility", 0.0))
    if volatility > 0.04:
        reasons.append("VOLATILITY_TOO_HIGH")
    if current_drawdown >= p.max_drawdown:
        reasons.append("MAX_DRAWDOWN")
    if equity > 0 and abs(min(0.0, daily_realized_loss)) / equity >= p.max_daily_loss:
        reasons.append("MAX_DAILY_LOSS")
    if open_positions >= p.max_open_positions:
        reasons.append("MAX_OPEN_POSITIONS")
    if spread_bps > p.max_spread_bps:
        reasons.append("SPREAD_TOO_WIDE")
    reasons = list(dict.fromkeys(reasons))
    score = min(1.0, len(reasons) * 0.2 + min(0.6, volatility * 10))
    risk_level = "HIGH" if score >= 0.7 else "MEDIUM" if score >= 0.35 else "LOW"
    return RiskAssessment(not reasons, risk_level, tuple(reasons), score)
