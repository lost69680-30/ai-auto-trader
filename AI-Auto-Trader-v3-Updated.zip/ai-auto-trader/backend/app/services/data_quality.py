from __future__ import annotations

from dataclasses import dataclass

from backend.app.domain.market import Candle


@dataclass(frozen=True)
class DataQualityReport:
    ok: bool
    reasons: tuple[str, ...]
    metrics: dict[str, float]


def assess_data_quality(
    candles: list[Candle],
    *,
    expected_interval_ms: int,
    now_ms: int,
    stale_after_ms: int | None = None,
) -> DataQualityReport:
    if not candles:
        return DataQualityReport(False, ("NO_DATA",), {})
    reasons: list[str] = []
    timestamps = [c.timestamp for c in candles]
    if len(timestamps) != len(set(timestamps)):
        reasons.append("DUPLICATE_TIMESTAMP")
    if any(b <= a for a, b in zip(timestamps, timestamps[1:])):
        if any(b < a for a, b in zip(timestamps, timestamps[1:])):
            reasons.append("OUT_OF_ORDER")
    gaps = [b - a for a, b in zip(timestamps, timestamps[1:]) if b > a]
    gap_count = sum(1 for gap in gaps if gap > expected_interval_ms * 1.5)
    if gap_count:
        reasons.append("MISSING_INTERVAL")
    threshold = stale_after_ms if stale_after_ms is not None else expected_interval_ms * 2
    age = now_ms - timestamps[-1]
    if age > threshold:
        reasons.append("STALE_DATA")
    return DataQualityReport(
        ok=not reasons,
        reasons=tuple(dict.fromkeys(reasons)),
        metrics={"latest_age_ms": float(age), "gap_count": float(gap_count)},
    )
