from __future__ import annotations

from dataclasses import dataclass
from time import time

from backend.app.domain.market import Candle, MarketAssessment
from backend.app.services.data_quality import assess_data_quality
from backend.app.services.market_analysis import analyze_market

_INTERVAL_MS = {
    "1m": 60_000,
    "3m": 180_000,
    "5m": 300_000,
    "15m": 900_000,
    "30m": 1_800_000,
    "1h": 3_600_000,
    "4h": 14_400_000,
    "1d": 86_400_000,
}


@dataclass(frozen=True)
class SymbolIntelligence:
    symbol: str
    timeframes: dict[str, MarketAssessment]
    overall_trend: str
    evidence_state: str
    risk_level: str
    alignment: float


def _from_binance(row: list) -> Candle:
    return Candle(int(row[0]), float(row[1]), float(row[2]), float(row[3]), float(row[4]), float(row[5]))


def analyze_symbol(adapter, symbol: str, intervals: list[str], *, now_ms: int | None = None) -> SymbolIntelligence:
    now = now_ms if now_ms is not None else int(time() * 1000)
    assessments: dict[str, MarketAssessment] = {}
    for interval in intervals:
        interval_ms = _INTERVAL_MS.get(interval)
        if interval_ms is None:
            continue
        raw = adapter.get_candles(symbol, interval, 200)
        candles = [_from_binance(row) for row in raw]
        assessment = analyze_market(candles, interval)
        quality = assess_data_quality(
            candles,
            expected_interval_ms=interval_ms,
            now_ms=now,
            stale_after_ms=interval_ms * 2,
        )
        if not quality.ok:
            assessment = MarketAssessment(
                timeframe=assessment.timeframe,
                regime=assessment.regime,
                features=assessment.features,
                risk_factors=assessment.risk_factors,
                data_quality="STALE_OR_INVALID",
                opportunity_state="NONE",
                reason_codes=tuple(dict.fromkeys(assessment.reason_codes + quality.reasons)),
            )
        assessments[interval] = assessment

    trends = [str(a.features.get("trend")) for a in assessments.values() if a.data_quality == "GOOD"]
    bullish = sum(t == "BULLISH" for t in trends)
    bearish = sum(t == "BEARISH" for t in trends)
    total = len(trends)
    overall = "BULLISH" if bullish > bearish else "BEARISH" if bearish > bullish else "NEUTRAL"
    alignment = (max(bullish, bearish) / total) if total else 0.0
    qualified = [a for a in assessments.values() if a.opportunity_state == "CANDIDATE" and a.data_quality == "GOOD"]
    bad_data = any(a.data_quality != "GOOD" for a in assessments.values())
    evidence = "CANDIDATE" if alignment >= 0.66 and qualified and not bad_data else "WATCH" if assessments else "NONE"
    risk = "HIGH" if any(float(a.risk_factors.get("volatility", 0.0)) > 0.04 for a in assessments.values()) else "MEDIUM" if alignment < 0.66 else "LOW"
    return SymbolIntelligence(symbol, assessments, overall, evidence, risk, alignment)
