from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StrategyHealthPolicy:
    max_drawdown: float = 0.10
    expectancy_drop_threshold: float = 0.25


@dataclass(frozen=True)
class StrategyHealth:
    state: str
    reasons: tuple[str, ...]


def evaluate_strategy_health(
    *,
    expected_expectancy: float,
    observed_expectancy: float,
    observed_drawdown: float,
    policy: StrategyHealthPolicy | None = None,
) -> StrategyHealth:
    p = policy or StrategyHealthPolicy()
    reasons: list[str] = []
    drop = expected_expectancy - observed_expectancy
    if observed_drawdown >= p.max_drawdown:
        reasons.append("DRAWDOWN_BREACH")
    if drop >= p.expectancy_drop_threshold:
        reasons.append("EXPECTANCY_DEGRADATION")
    state = "PAUSED" if "DRAWDOWN_BREACH" in reasons else "DEGRADED" if reasons else "NORMAL"
    return StrategyHealth(state, tuple(reasons))
