from __future__ import annotations

from dataclasses import dataclass


class UnknownExecution(RuntimeError):
    """The exchange response is unknown; reconcile before any retry."""


@dataclass(frozen=True)
class ExecutionIntent:
    client_order_id: str
    symbol: str
    side: str
    quantity: float
    stop_price: float
    take_profit_price: float


class ExecutionService:
    def __init__(self, adapter) -> None:
        self.adapter = adapter
        self._completed: dict[str, dict] = {}

    def submit(self, intent: ExecutionIntent) -> dict:
        if intent.client_order_id in self._completed:
            return self._completed[intent.client_order_id]
        try:
            result = self.adapter.place_order(intent)
        except UnknownExecution:
            result = self.adapter.get_order_status(intent.client_order_id, intent.symbol)
            if result is None:
                raise
        self._completed[intent.client_order_id] = result
        return result
