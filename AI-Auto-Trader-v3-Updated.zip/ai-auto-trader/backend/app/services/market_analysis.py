from __future__ import annotations

from statistics import pstdev

from backend.app.domain.market import Candle, MarketAssessment


def _sma(values: list[float], window: int) -> float:
    sample = values[-window:]
    return sum(sample) / len(sample)


def _returns(closes: list[float]) -> list[float]:
    return [closes[i] / closes[i - 1] - 1 for i in range(1, len(closes)) if closes[i - 1] != 0]


def _atr(candles: list[Candle], window: int = 14) -> float:
    trs: list[float] = []
    prev_close = None
    for c in candles:
        tr = c.high - c.low if prev_close is None else max(c.high - c.low, abs(c.high - prev_close), abs(c.low - prev_close))
        trs.append(tr)
        prev_close = c.close
    return sum(trs[-min(window, len(trs)):]) / min(window, len(trs))


def analyze_market(candles: list[Candle], timeframe: str) -> MarketAssessment:
    if len(candles) < 5:
        return MarketAssessment(
            timeframe=timeframe,
            regime="UNKNOWN",
            features={},
            risk_factors={},
            data_quality="INSUFFICIENT",
            opportunity_state="NONE",
            reason_codes=("INSUFFICIENT_DATA",),
        )

    closes = [c.close for c in candles]
    last = candles[-1]
    ranges = [c.high - c.low for c in candles]
    returns = _returns(closes)
    momentum_window = min(5, len(closes) - 1)
    momentum = closes[-1] / closes[-1 - momentum_window] - 1
    atr = _atr(candles)
    volatility = pstdev(returns[-min(20, len(returns)):]) if len(returns) > 1 else 0.0
    fast = _sma(closes, min(5, len(closes)))
    slow = _sma(closes, min(10, len(closes)))
    trend = "BULLISH" if fast > slow * 1.001 else "BEARISH" if fast < slow * 0.999 else "NEUTRAL"
    avg_volume = _sma([c.volume for c in candles], min(20, len(candles)))
    relative_volume = last.volume / avg_volume if avg_volume else 0.0

    body = abs(last.close - last.open)
    upper_wick = last.high - max(last.open, last.close)
    lower_wick = min(last.open, last.close) - last.low
    normalized_trend = abs(fast - slow) / last.close if last.close else 0.0

    if normalized_trend >= 0.01 and abs(momentum) >= 0.01:
        regime = "TRENDING"
    elif volatility >= 0.01:
        regime = "HIGH_VOLATILITY"
    else:
        regime = "RANGING"

    reasons: list[str] = []
    if trend == "BULLISH":
        reasons.append("BULLISH_TREND")
    elif trend == "BEARISH":
        reasons.append("BEARISH_TREND")
    if relative_volume >= 1.25:
        reasons.append("VOLUME_EXPANSION")

    opportunity = "WATCH"
    if regime == "TRENDING" and relative_volume >= 1.0 and abs(momentum) >= 0.005:
        opportunity = "CANDIDATE"
    if volatility > 0.04:
        opportunity = "NONE"
        reasons.append("VOLATILITY_TOO_HIGH")

    features: dict[str, float | str] = {
        "last_close": last.close,
        "body": body,
        "upper_wick": upper_wick,
        "lower_wick": lower_wick,
        "range": last.high - last.low,
        "atr": atr,
        "momentum": momentum,
        "volatility": volatility,
        "trend": trend,
        "fast_sma": fast,
        "slow_sma": slow,
        "relative_volume": relative_volume,
    }
    risk_factors: dict[str, float | str] = {
        "volatility": volatility,
        "liquidity_proxy": relative_volume,
        "trend_uncertainty": max(0.0, 0.01 - normalized_trend),
    }
    return MarketAssessment(
        timeframe=timeframe,
        regime=regime,
        features=features,
        risk_factors=risk_factors,
        data_quality="GOOD",
        opportunity_state=opportunity,
        reason_codes=tuple(reasons),
    )
