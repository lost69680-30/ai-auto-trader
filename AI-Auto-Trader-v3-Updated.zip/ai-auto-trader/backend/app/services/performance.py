from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TradeOutcome:
    net_pnl: float


@dataclass(frozen=True)
class Performance:
    trade_count: int
    win_rate: float | None
    expectancy: float
    profit_factor: float | None
    max_drawdown: float
    net_pnl: float


def calculate_performance(trades: list[TradeOutcome], *, initial_equity: float) -> Performance:
    if not trades:
        return Performance(0, None, 0.0, None, 0.0, 0.0)
    pnl = [t.net_pnl for t in trades]
    wins = [x for x in pnl if x > 0]
    losses = [x for x in pnl if x < 0]
    equity = initial_equity
    peak = initial_equity
    max_dd = 0.0
    for value in pnl:
        equity += value
        peak = max(peak, equity)
        max_dd = max(max_dd, (peak - equity) / peak if peak else 0.0)
    gross_loss = abs(sum(losses))
    profit_factor = sum(wins) / gross_loss if gross_loss else None
    return Performance(
        len(pnl),
        len(wins) / len(pnl),
        sum(pnl) / len(pnl),
        profit_factor,
        max_dd,
        sum(pnl),
    )
