from __future__ import annotations

import json
from dataclasses import dataclass

import httpx

from backend.app.domain.market import MarketAssessment


@dataclass(frozen=True)
class AiAdvice:
    provider: str
    action: str
    confidence: float
    rationale: str
    can_execute: bool = False


class AiAdvisor:
    """Optional explanation/ranking layer. It never owns execution authority."""

    def __init__(self, api_key: str | None, model: str = "gpt-6-astra") -> None:
        self.api_key = api_key
        self.model = model

    def advise(self, assessment: MarketAssessment) -> AiAdvice:
        if not self.api_key:
            return self._rules_fallback(assessment)
        try:
            payload = {
                "model": self.model,
                "store": False,
                "input": [
                    {"role": "system", "content": "You are a market-analysis advisor. Never issue executable orders or position sizes. Return only the requested structured analysis."},
                    {"role": "user", "content": json.dumps({"regime": assessment.regime, "features": assessment.features, "risk_factors": assessment.risk_factors, "data_quality": assessment.data_quality, "opportunity_state": assessment.opportunity_state, "reason_codes": assessment.reason_codes})},
                ],
                "text": {"format": {
                    "type": "json_schema",
                    "name": "market_advice",
                    "strict": True,
                    "schema": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "action": {"type": "string", "enum": ["LONG", "SHORT", "WATCH", "NO_TRADE"]},
                            "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                            "rationale": {"type": "string"},
                        },
                        "required": ["action", "confidence", "rationale"],
                    },
                }},
            }
            response = httpx.post("https://api.openai.com/v1/responses", headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}, json=payload, timeout=20.0)
            response.raise_for_status()
            body = response.json()
            text = body.get("output_text")
            if not text:
                for item in body.get("output", []):
                    for content in item.get("content", []):
                        if content.get("type") == "output_text":
                            text = content.get("text")
                            break
                    if text:
                        break
            parsed = json.loads(text or "{}")
            return AiAdvice("openai", str(parsed["action"]), float(parsed["confidence"]), str(parsed["rationale"]), False)
        except Exception:
            return self._rules_fallback(assessment)

    @staticmethod
    def _rules_fallback(assessment: MarketAssessment) -> AiAdvice:
        if assessment.data_quality != "GOOD":
            return AiAdvice("rules", "NO_TRADE", 0.99, "Market data quality is insufficient or stale; execution authority remains disabled.")
        trend = assessment.features.get("trend")
        if assessment.opportunity_state != "CANDIDATE":
            return AiAdvice("rules", "WATCH", 0.75, "Conditions are not strong enough to classify as a qualified opportunity.")
        if trend == "BULLISH":
            return AiAdvice("rules", "LONG", 0.65, "Trend and momentum align with a qualified candidate state.")
        if trend == "BEARISH":
            return AiAdvice("rules", "SHORT", 0.65, "Trend and momentum align with a qualified candidate state.")
        return AiAdvice("rules", "NO_TRADE", 0.75, "Direction is not confirmed.")
