from __future__ import annotations

import json
from dataclasses import dataclass

from fastapi import FastAPI, WebSocket

from backend.app.adapters.binance_testnet import BinanceTestnetAdapter
from backend.app.config import Settings
from backend.app.db import Base, engine, session
from backend.app.models import AuditEvent
from backend.app.services.market_intelligence import analyze_symbol
from backend.app.services.ai_advisor import AiAdvisor


@dataclass
class RuntimeState:
    emergency_stop: bool = False
    automation_running: bool = False


settings = Settings()
Base.metadata.create_all(engine)
adapter = BinanceTestnetAdapter(settings)
runtime = RuntimeState()
app = FastAPI(title="AI Auto Trader API", version="0.1.0")


def record(event_type: str, payload: dict) -> None:
    db = session()
    try:
        db.add(AuditEvent(event_type=event_type, payload=json.dumps(payload, sort_keys=True)))
        db.commit()
    finally:
        db.close()


@app.get("/health")
def health():
    return {
        "status": "ok",
        "environment": settings.environment,
        "live_enabled": settings.live_enabled,
        "credentials_configured": bool(settings.binance_api_key and settings.binance_api_secret),
        "emergency_stop": runtime.emergency_stop,
        "automation_running": runtime.automation_running,
    }


@app.post("/auth/login")
def login():
    return {"status": "authentication_not_configured", "message": "Configure the production auth provider before enabling remote users."}


@app.get("/markets")
def markets():
    info = adapter.get_exchange_info()
    return {"symbols": [s["symbol"] for s in info.get("symbols", []) if s.get("status") == "TRADING"]}


@app.get("/markets/{symbol}/candles")
def candles(symbol: str, interval: str = "15m", limit: int = 200):
    rows = adapter.get_candles(symbol, interval, limit)
    return {"symbol": symbol.upper(), "interval": interval, "candles": rows}


@app.get("/markets/{symbol}/analysis")
def market_analysis(symbol: str, intervals: str = "5m,15m,1h"):
    requested = [item.strip() for item in intervals.split(",") if item.strip()]
    result = analyze_symbol(adapter, symbol.upper(), requested)
    return {
        "symbol": result.symbol,
        "overall_trend": result.overall_trend,
        "evidence_state": result.evidence_state,
        "risk_level": result.risk_level,
        "alignment": result.alignment,
        "timeframes": {
            tf: {
                "regime": assessment.regime,
                "data_quality": assessment.data_quality,
                "opportunity_state": assessment.opportunity_state,
                "reason_codes": list(assessment.reason_codes),
                "features": assessment.features,
                "risk_factors": assessment.risk_factors,
            }
            for tf, assessment in result.timeframes.items()
        },
    }


@app.get("/markets/{symbol}/ai-analysis")
def ai_market_analysis(symbol: str):
    result = analyze_symbol(adapter, symbol.upper(), ["5m", "15m", "1h"])
    assessment = result.timeframes.get("15m")
    if assessment is None:
        return {"provider": "rules", "action": "NO_TRADE", "confidence": 1.0, "rationale": "No analysis available.", "can_execute": False}
    advice = AiAdvisor(settings.openai_api_key, settings.openai_model).advise(assessment)
    return {"provider": advice.provider, "action": advice.action, "confidence": advice.confidence, "rationale": advice.rationale, "can_execute": advice.can_execute}


@app.get("/account/summary")
def account_summary():
    if not settings.binance_api_key or not settings.binance_api_secret:
        return {"available": False, "reason": "TESTNET credentials not configured"}
    account = adapter.get_account_summary()
    return {"available": True, "balances": account.get("balances", [])}


@app.get("/positions")
def positions():
    return {"positions": []}


@app.get("/orders")
def orders():
    return {"orders": []}


@app.get("/performance")
def performance():
    return {"net_pnl": 0.0, "win_rate": None, "drawdown": 0.0, "trade_count": 0}


@app.get("/risk")
def risk():
    return {"emergency_stop": runtime.emergency_stop, "risk_level": "UNKNOWN", "reasons": ["NO_LIVE_STRATEGY_RUN"]}


@app.post("/risk/emergency-stop")
def emergency_stop():
    runtime.emergency_stop = True
    runtime.automation_running = False
    record("EMERGENCY_STOP", {"source": "api"})
    return {"emergency_stop": True, "automation_running": False}


@app.post("/risk/emergency-resume")
def emergency_resume():
    runtime.emergency_stop = False
    record("EMERGENCY_RESUME", {"source": "api"})
    return {"emergency_stop": False}


@app.post("/automation/start")
def automation_start():
    if runtime.emergency_stop:
        return {"running": False, "reason": "EMERGENCY_STOP"}
    runtime.automation_running = True
    record("AUTOMATION_START", {"source": "api"})
    return {"running": True}


@app.post("/automation/stop")
def automation_stop():
    runtime.automation_running = False
    record("AUTOMATION_STOP", {"source": "api"})
    return {"running": False}


@app.get("/automation/status")
def automation_status():
    return {"running": runtime.automation_running, "emergency_stop": runtime.emergency_stop, "environment": settings.environment}


@app.websocket("/ws")
async def websocket(ws: WebSocket):
    await ws.accept()
    await ws.send_json({"type": "state", "running": runtime.automation_running, "emergency_stop": runtime.emergency_stop, "environment": settings.environment})
