from __future__ import annotations

from dataclasses import dataclass

import httpx

from backend.app.config import Settings


@dataclass(frozen=True)
class OandaStatus:
    environment: str
    authenticated: bool
    practice: bool


class OandaPracticeAdapter:
    """Forex adapter targeting OANDA fxTrade Practice only.

    Credentials are read from backend environment variables and never returned
    by repr/status. Live OANDA execution is intentionally unsupported here.
    """

    def __init__(self, settings: Settings) -> None:
        self.base_url = settings.oanda_practice_base_url.rstrip("/")
        self.account_id = settings.oanda_account_id
        self._token = settings.oanda_api_token
        self.is_practice = settings.environment == "testnet"
        self.client = httpx.Client(base_url=self.base_url, timeout=10.0)

    def __repr__(self) -> str:
        return f"OandaPracticeAdapter(base_url={self.base_url!r}, practice={self.is_practice}, authenticated={bool(self.account_id and self._token)})"

    def public_status(self) -> dict:
        return {
            "environment": "practice" if self.is_practice else "live",
            "authenticated": bool(self.account_id and self._token),
            "practice": self.is_practice,
        }

    def _headers(self) -> dict[str, str]:
        if not self._token:
            raise RuntimeError("OANDA API token is not configured")
        return {"Authorization": f"Bearer {self._token}", "Content-Type": "application/json"}

    def get_candles(self, instrument: str, granularity: str = "M15", count: int = 200) -> list[dict]:
        response = self.client.get(
            f"/v3/instruments/{instrument.upper()}/candles",
            params={"granularity": granularity, "count": min(count, 5000), "price": "MBA"},
            headers=self._headers(),
        )
        response.raise_for_status()
        return response.json()["candles"]

    def get_account_summary(self) -> dict:
        if not self.account_id:
            raise RuntimeError("OANDA account ID is not configured")
        response = self.client.get(f"/v3/accounts/{self.account_id}", headers=self._headers())
        response.raise_for_status()
        return response.json()

    def place_order(self, intent) -> dict:
        if not self.is_practice:
            raise RuntimeError("Live OANDA execution is disabled in this build")
        if not self.account_id:
            raise RuntimeError("OANDA account ID is not configured")
        units = intent.quantity if intent.side.upper() in {"BUY", "LONG"} else -intent.quantity
        order = {
            "order": {
                "instrument": intent.symbol.upper(),
                "units": str(units),
                "type": "MARKET",
                "timeInForce": "FOK",
                "positionFill": "DEFAULT",
                "clientExtensions": {"id": intent.client_order_id},
                "stopLossOnFill": {"price": str(intent.stop_price)},
                "takeProfitOnFill": {"price": str(intent.take_profit_price)},
            }
        }
        response = self.client.post(
            f"/v3/accounts/{self.account_id}/orders", json=order, headers=self._headers()
        )
        response.raise_for_status()
        return response.json()

    def get_order_status(self, client_order_id: str, symbol: str) -> dict | None:
        if not self.account_id:
            raise RuntimeError("OANDA account ID is not configured")
        response = self.client.get(
            f"/v3/accounts/{self.account_id}/orders/@{client_order_id}",
            headers=self._headers(),
        )
        if response.status_code == 404:
            return None
        response.raise_for_status()
        return response.json()
