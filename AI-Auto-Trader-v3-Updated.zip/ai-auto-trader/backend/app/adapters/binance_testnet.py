from __future__ import annotations

import hashlib
import hmac
import time
from dataclasses import dataclass
from urllib.parse import urlencode

import httpx

from backend.app.config import Settings


@dataclass(frozen=True)
class AdapterStatus:
    environment: str
    authenticated: bool
    testnet: bool


class BinanceTestnetAdapter:
    def __init__(self, settings: Settings) -> None:
        self.base_url = settings.binance_testnet_base_url.rstrip("/")
        self.api_key = settings.binance_api_key
        self._api_secret = settings.binance_api_secret
        self.is_testnet = settings.environment == "testnet"
        self.client = httpx.Client(base_url=self.base_url, timeout=10.0)

    def __repr__(self) -> str:
        return f"BinanceTestnetAdapter(base_url={self.base_url!r}, testnet={self.is_testnet}, authenticated={bool(self.api_key and self._api_secret)})"

    def public_status(self) -> dict:
        return {"environment": "testnet" if self.is_testnet else "live", "authenticated": bool(self.api_key and self._api_secret), "testnet": self.is_testnet}

    def signed_params(self, params: dict) -> dict:
        if not self._api_secret:
            raise RuntimeError("Binance API secret is not configured")
        ordered = dict(params)
        query = urlencode(ordered)
        signature = hmac.new(self._api_secret.encode(), query.encode(), hashlib.sha256).hexdigest()
        ordered["signature"] = signature
        return ordered

    def _request(self, method: str, path: str, *, params: dict | None = None, signed: bool = False) -> dict | list:
        params = dict(params or {})
        headers = {}
        if signed:
            if not self.api_key or not self._api_secret:
                raise RuntimeError("Binance credentials are not configured")
            params.setdefault("timestamp", int(time.time() * 1000))
            params.setdefault("recvWindow", 5000)
            params = self.signed_params(params)
            headers["X-MBX-APIKEY"] = self.api_key
        response = self.client.request(method, path, params=params, headers=headers)
        response.raise_for_status()
        return response.json()

    def get_exchange_info(self) -> dict:
        return self._request("GET", "/api/v3/exchangeInfo")  # type: ignore[return-value]

    def get_candles(self, symbol: str, interval: str = "15m", limit: int = 200) -> list:
        return self._request("GET", "/api/v3/klines", params={"symbol": symbol.upper(), "interval": interval, "limit": min(limit, 1000)})  # type: ignore[return-value]

    def get_account_summary(self) -> dict:
        return self._request("GET", "/api/v3/account", signed=True)  # type: ignore[return-value]

    def place_order(self, intent) -> dict:
        if not self.is_testnet:
            raise RuntimeError("Live Binance execution is disabled in this build")
        params = {
            "symbol": intent.symbol.upper(),
            "side": "BUY" if intent.side.upper() in {"BUY", "LONG"} else "SELL",
            "type": "MARKET",
            "quantity": f"{intent.quantity:.12f}".rstrip("0").rstrip("."),
            "newClientOrderId": intent.client_order_id,
        }
        return self._request("POST", "/api/v3/order", params=params, signed=True)  # type: ignore[return-value]

    def get_order_status(self, client_order_id: str, symbol: str) -> dict:
        return self._request("GET", "/api/v3/order", params={"symbol": symbol.upper(), "origClientOrderId": client_order_id}, signed=True)  # type: ignore[return-value]
