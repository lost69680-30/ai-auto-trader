from backend.app.services.market_intelligence import analyze_symbol


def rows(values, start=1_700_000_000_000, interval_ms=300_000):
    return [[start + i * interval_ms, v, v + 1, v - 1, v, 1000, start + (i + 1) * interval_ms - 1, 1000, 10, 1000, 100, 0] for i, v in enumerate(values)]


class FakeAdapter:
    def __init__(self):
        self.calls = []
    def get_candles(self, symbol, interval, limit=200):
        self.calls.append(interval)
        return rows([100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111], interval_ms={"5m": 300_000, "15m": 900_000, "1h": 3_600_000}[interval])


def test_market_intelligence_combines_multiple_timeframes():
    result = analyze_symbol(FakeAdapter(), "BTCUSDT", ["5m", "15m", "1h"], now_ms=1_700_000_000_000 + 11 * 3_600_000)
    assert set(result.timeframes) == {"5m", "15m", "1h"}
    assert result.overall_trend == "BULLISH"
    assert result.evidence_state in {"WATCH", "CANDIDATE"}
