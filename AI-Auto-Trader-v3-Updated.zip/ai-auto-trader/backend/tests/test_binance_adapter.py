import hashlib
import hmac

from backend.app.adapters.binance_testnet import BinanceTestnetAdapter
from backend.app.config import Settings


def test_binance_adapter_uses_testnet_by_default():
    adapter = BinanceTestnetAdapter(Settings())
    assert adapter.base_url == "https://testnet.binance.vision"
    assert adapter.is_testnet


def test_binance_adapter_signs_query_parameters():
    adapter = BinanceTestnetAdapter(Settings(binance_api_key="key", binance_api_secret="secret"))
    params = {"symbol": "BTCUSDT", "timestamp": 1700000000000}
    signed = adapter.signed_params(params)
    expected = hmac.new(b"secret", "symbol=BTCUSDT&timestamp=1700000000000".encode(), hashlib.sha256).hexdigest()
    assert signed["signature"] == expected


def test_binance_adapter_never_returns_secret():
    adapter = BinanceTestnetAdapter(Settings(binance_api_key="key", binance_api_secret="secret"))
    assert "secret" not in repr(adapter)
    assert "secret" not in str(adapter.public_status())
