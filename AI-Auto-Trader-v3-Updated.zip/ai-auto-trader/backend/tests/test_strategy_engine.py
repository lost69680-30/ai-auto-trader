from backend.app.domain.market import Candle
from backend.app.services.market_analysis import analyze_market
from backend.app.services.strategy_engine import evaluate_strategy


def candles(values):
    return [Candle(1_700_000_000 + i * 60_000, v, v + 1, v - 1, v, 1000) for i, v in enumerate(values)]


def test_baseline_strategy_requires_candidate_trend():
    result = evaluate_strategy(analyze_market(candles([100, 101, 102, 103, 104, 105, 106, 107, 108, 109]), "15m"))
    assert result.side == "LONG"
    assert result.confidence > 0
    assert "BULLISH_TREND" in result.reason_codes


def test_strategy_returns_no_trade_when_analysis_blocks():
    result = evaluate_strategy(analyze_market(candles([100, 130, 90, 140, 80, 150, 70, 160]), "15m"))
    assert result.side == "NONE"
