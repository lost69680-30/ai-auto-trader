from backend.app.services.performance import TradeOutcome, calculate_performance


def test_performance_calculates_expectancy_profit_factor_and_drawdown():
    result = calculate_performance([
        TradeOutcome(100),
        TradeOutcome(-40),
        TradeOutcome(60),
        TradeOutcome(-20),
    ], initial_equity=1000)
    assert result.trade_count == 4
    assert result.win_rate == 0.5
    assert result.expectancy == 25
    assert round(result.profit_factor, 6) == round(160 / 60, 6)
    assert result.max_drawdown > 0
