from dataclasses import dataclass

from backend.app.services.execution import ExecutionService, ExecutionIntent, UnknownExecution


@dataclass
class FakeAdapter:
    submissions: int = 0
    status_queries: int = 0
    order_id: str = "EX-1"

    def place_order(self, intent):
        self.submissions += 1
        raise UnknownExecution("timeout")

    def get_order_status(self, client_order_id, symbol):
        self.status_queries += 1
        return {"status": "FILLED", "orderId": self.order_id, "clientOrderId": client_order_id}


def test_unknown_execution_is_reconciled_before_retry():
    adapter = FakeAdapter()
    service = ExecutionService(adapter)
    intent = ExecutionIntent(client_order_id="AIAT-1", symbol="BTCUSDT", side="BUY", quantity=0.01, stop_price=90, take_profit_price=120)
    result = service.submit(intent)
    assert result["status"] == "FILLED"
    assert adapter.submissions == 1
    assert adapter.status_queries == 1


def test_duplicate_client_order_id_does_not_resubmit():
    class Adapter:
        def __init__(self): self.calls = 0
        def place_order(self, intent): self.calls += 1; return {"status": "NEW", "orderId": "1"}
        def get_order_status(self, cid, symbol): return {"status": "NEW", "orderId": "1"}
    adapter = Adapter()
    service = ExecutionService(adapter)
    intent = ExecutionIntent("AIAT-2", "BTCUSDT", "BUY", 0.01, 90, 120)
    service.submit(intent)
    service.submit(intent)
    assert adapter.calls == 1
