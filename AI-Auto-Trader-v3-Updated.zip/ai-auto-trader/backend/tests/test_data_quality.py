from backend.app.domain.market import Candle
from backend.app.services.data_quality import assess_data_quality


def c(ts):
    return Candle(ts, 100, 101, 99, 100.5, 1000)


def test_data_quality_detects_duplicate_and_out_of_order_data():
    report = assess_data_quality([c(0), c(60_000), c(60_000), c(30_000)], expected_interval_ms=60_000, now_ms=60_000)
    assert not report.ok
    assert "DUPLICATE_TIMESTAMP" in report.reasons
    assert "OUT_OF_ORDER" in report.reasons


def test_data_quality_detects_stale_data():
    report = assess_data_quality([c(0), c(60_000)], expected_interval_ms=60_000, now_ms=180_001, stale_after_ms=60_000)
    assert not report.ok
    assert "STALE_DATA" in report.reasons


def test_data_quality_is_good_for_clean_sequence():
    report = assess_data_quality([c(0), c(60_000), c(120_000)], expected_interval_ms=60_000, now_ms=120_001, stale_after_ms=60_000)
    assert report.ok
