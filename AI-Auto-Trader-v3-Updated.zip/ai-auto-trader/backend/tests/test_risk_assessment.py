from backend.app.domain.market import Candle
from backend.app.services.market_analysis import analyze_market
from backend.app.services.risk_assessment import RiskPolicy, assess_risk


def candles(values):
    return [Candle(1_700_000_000 + i * 60_000, v, v + 2, v - 2, v + 1, 1000) for i, v in enumerate(values)]


def test_risk_assessment_blocks_insufficient_data():
    m = analyze_market(candles([100, 101]), "5m")
    result = assess_risk(m, equity=10_000, daily_realized_loss=0, current_drawdown=0, open_positions=0, spread_bps=1)
    assert not result.approved
    assert "INSUFFICIENT_DATA" in result.reasons


def test_risk_assessment_blocks_high_volatility():
    m = analyze_market(candles([100, 130, 90, 140, 80, 150, 70, 160]), "5m")
    result = assess_risk(m, equity=10_000, daily_realized_loss=0, current_drawdown=0, open_positions=0, spread_bps=1)
    assert not result.approved
    assert "VOLATILITY_TOO_HIGH" in result.reasons


def test_risk_assessment_blocks_drawdown_and_spread():
    m = analyze_market(candles([100, 101, 102, 103, 104]), "5m")
    policy = RiskPolicy(max_drawdown=0.05, max_daily_loss=0.02, max_open_positions=3, max_spread_bps=10)
    result = assess_risk(m, equity=10_000, daily_realized_loss=-50, current_drawdown=0.06, open_positions=1, spread_bps=25, policy=policy)
    assert not result.approved
    assert "MAX_DRAWDOWN" in result.reasons
    assert "SPREAD_TOO_WIDE" in result.reasons
