from backend.app.config import Settings


def test_settings_repr_hides_secrets():
    value = Settings(binance_api_key="PUBLIC", binance_api_secret="SUPER_SECRET", openai_api_key="OPENAI_SECRET")
    rendered = repr(value)
    assert "SUPER_SECRET" not in rendered
    assert "OPENAI_SECRET" not in rendered
