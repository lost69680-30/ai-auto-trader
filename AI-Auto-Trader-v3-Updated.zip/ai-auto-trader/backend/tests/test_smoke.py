def test_settings_default_to_testnet():
    from backend.app.config import Settings
    assert Settings().environment == 'testnet'
