from backend.app.domain.market import Candle
from backend.app.domain.strategy import StrategySignal
from backend.app.services.market_analysis import analyze_market
from backend.app.services.risk_assessment import RiskAssessment
from backend.app.services.risk_engine import RiskEngine, RiskPolicy


def assessment():
    cs = [Candle(1_700_000_000 + i * 60_000, 100 + i, 102 + i, 99 + i, 101 + i, 1000) for i in range(10)]
    return analyze_market(cs, "15m")


def signal():
    return StrategySignal("LONG", 0.8, ("BULLISH_TREND",), 1.5, 3.0)


def test_risk_engine_sizes_position_from_risk_budget():
    engine = RiskEngine(RiskPolicy(risk_per_trade=0.005, max_open_positions=3, max_daily_loss=0.02, max_drawdown=0.05))
    decision = engine.approve(signal(), assessment(), equity=10_000, daily_realized_loss=0, drawdown=0, open_positions=0, emergency_stop=False)
    assert decision.approved
    assert decision.quantity > 0
    assert decision.risk_amount <= 50.0


def test_risk_engine_blocks_emergency_stop():
    engine = RiskEngine()
    decision = engine.approve(signal(), assessment(), equity=10_000, daily_realized_loss=0, drawdown=0, open_positions=0, emergency_stop=True)
    assert not decision.approved
    assert "EMERGENCY_STOP" in decision.reasons


def test_risk_engine_blocks_missing_protection():
    engine = RiskEngine()
    unprotected = StrategySignal("LONG", 0.8, (), None, None)
    decision = engine.approve(unprotected, assessment(), equity=10_000, daily_realized_loss=0, drawdown=0, open_positions=0, emergency_stop=False)
    assert not decision.approved
    assert "PROTECTED_EXIT_REQUIRED" in decision.reasons
