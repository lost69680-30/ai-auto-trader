from backend.app.domain.market import MarketAssessment
from backend.app.services.ai_advisor import AiAdvisor


def test_ai_advisor_without_key_is_safe_and_non_executing():
    assessment = MarketAssessment("15m", "TRENDING", {"trend": "BULLISH", "momentum": 0.02}, {"volatility": 0.01}, "GOOD", "CANDIDATE", ("BULLISH_TREND",))
    advice = AiAdvisor(api_key=None).advise(assessment)
    assert advice.provider == "rules"
    assert advice.action in {"WATCH", "LONG", "SHORT", "NO_TRADE"}
    assert advice.can_execute is False
