from backend.app.adapters.oanda_practice import OandaPracticeAdapter
from backend.app.config import Settings


def test_oanda_adapter_defaults_to_practice_and_hides_token():
    s = Settings(oanda_account_id="demo", oanda_api_token="SECRET")
    a = OandaPracticeAdapter(s)
    assert a.is_practice is True
    assert a.public_status()["authenticated"] is True
    assert "SECRET" not in repr(a)


def test_oanda_live_execution_is_blocked():
    s = Settings(environment="live", live_enabled=True, oanda_account_id="demo", oanda_api_token="SECRET")
    a = OandaPracticeAdapter(s)
    class Intent:
        symbol="EUR_USD"; side="BUY"; quantity=100; stop_price=1.0; take_profit_price=1.2; client_order_id="x"
    try:
        a.place_order(Intent())
    except RuntimeError as e:
        assert "disabled" in str(e).lower()
    else:
        raise AssertionError("live OANDA execution must remain disabled")
