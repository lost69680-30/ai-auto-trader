from backend.app.domain.market import Candle
from backend.app.services.backtesting import BacktestCosts, backtest
from backend.app.services.strategy_engine import baseline_strategy


def candles(values):
    return [Candle(1_700_000_000 + i * 60_000, v, v + 1, v - 1, v, 1000) for i, v in enumerate(values)]


def test_backtest_accounts_for_fees_and_slippage():
    data = candles([100, 101, 102, 103, 104, 103, 105, 106, 107, 106, 108, 110])
    free = backtest(baseline_strategy, data, initial_equity=10_000, costs=BacktestCosts(fee_bps=0, slippage_bps=0))
    costly = backtest(baseline_strategy, data, initial_equity=10_000, costs=BacktestCosts(fee_bps=20, slippage_bps=10))
    assert costly.net_pnl <= free.net_pnl
    assert costly.total_fees > 0


def test_backtest_does_not_use_future_candles_for_a_decision():
    prefix = candles([100, 101, 102, 103, 104, 105, 106, 107, 108, 109])
    altered = prefix + [Candle(1_700_000_600, 500, 501, 499, 500, 1000)]
    a = baseline_strategy(prefix, "15m")
    b = baseline_strategy(prefix, "15m")
    assert a.side == b.side
    assert len(altered) == len(prefix) + 1
