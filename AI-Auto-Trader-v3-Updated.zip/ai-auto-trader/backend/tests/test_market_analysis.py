from backend.app.domain.market import Candle
from backend.app.services.market_analysis import analyze_market


def candles(values, volume=100.0):
    out = []
    for i, close in enumerate(values):
        open_ = values[i - 1] if i else close
        high = max(open_, close) + 1
        low = min(open_, close) - 1
        out.append(Candle(timestamp=1_700_000_000 + i * 60_000, open=open_, high=high, low=low, close=close, volume=volume))
    return out


def test_market_analysis_calculates_candle_features():
    result = analyze_market(candles([100, 102, 104, 106, 108, 110]), "5m")
    assert result.features["last_close"] == 110
    assert result.features["body"] == 2
    assert result.features["range"] == 4
    assert result.features["momentum"] > 0
    assert result.features["atr"] > 0


def test_market_analysis_detects_trending_regime():
    result = analyze_market(candles([100, 102, 104, 106, 108, 110, 112, 114, 116, 118]), "15m")
    assert result.regime == "TRENDING"
    assert result.features["trend"] == "BULLISH"


def test_market_analysis_rejects_insufficient_data():
    result = analyze_market(candles([100, 101]), "1m")
    assert result.data_quality == "INSUFFICIENT"
    assert result.opportunity_state == "NONE"
    assert "INSUFFICIENT_DATA" in result.reason_codes
