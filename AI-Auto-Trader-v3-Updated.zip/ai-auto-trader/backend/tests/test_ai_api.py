from fastapi.testclient import TestClient

from backend.app.main import app, adapter


def test_ai_analysis_endpoint_is_non_executing(monkeypatch):
    import time

    def fake_candles(symbol, interval, limit=200):
        start = int(time.time() * 1000) - 11 * 900_000
        return [[start + i * 900_000, 100 + i, 101 + i, 99 + i, 100 + i, 1000, start + (i + 1) * 900_000 - 1, 1000, 1, 100, 50, 0] for i in range(12)]

    monkeypatch.setattr(adapter, "get_candles", fake_candles)
    response = TestClient(app).get("/markets/BTCUSDT/ai-analysis")
    assert response.status_code == 200
    body = response.json()
    assert body["can_execute"] is False
    assert body["action"] in {"LONG", "SHORT", "WATCH", "NO_TRADE"}
