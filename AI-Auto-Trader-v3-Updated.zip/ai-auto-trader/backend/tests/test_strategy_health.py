from backend.app.services.strategy_health import StrategyHealthPolicy, evaluate_strategy_health


def test_strategy_health_pauses_on_material_degradation():
    result = evaluate_strategy_health(
        expected_expectancy=0.20,
        observed_expectancy=-0.20,
        observed_drawdown=0.12,
        policy=StrategyHealthPolicy(max_drawdown=0.10, expectancy_drop_threshold=0.25),
    )
    assert result.state == "PAUSED"
    assert "DRAWDOWN_BREACH" in result.reasons
    assert "EXPECTANCY_DEGRADATION" in result.reasons
