from fastapi.testclient import TestClient

from backend.app.main import app, runtime


def test_health_reports_testnet_mode():
    client = TestClient(app)
    response = client.get("/health")
    assert response.status_code == 200
    body = response.json()
    assert body["environment"] == "testnet"
    assert body["live_enabled"] is False


def test_risk_emergency_stop_changes_server_state():
    client = TestClient(app)
    runtime.emergency_stop = False
    response = client.post("/risk/emergency-stop")
    assert response.status_code == 200
    assert response.json()["emergency_stop"] is True
    assert runtime.emergency_stop is True
    client.post("/risk/emergency-resume")


def test_automation_status_is_safe_by_default():
    client = TestClient(app)
    runtime.automation_running = False
    response = client.get("/automation/status")
    assert response.status_code == 200
    assert response.json()["running"] is False


def test_market_analysis_endpoint_returns_multi_timeframe_evidence(monkeypatch):
    from backend.app.main import adapter

    def fake_candles(symbol, interval, limit=200):
        import time
        start = int(time.time() * 1000) - 12 * {"5m": 300_000, "15m": 900_000, "1h": 3_600_000}[interval]
        step = {"5m": 300_000, "15m": 900_000, "1h": 3_600_000}[interval]
        return [[start + i * step, 100 + i, 101 + i, 99 + i, 100 + i, 1000, start + (i + 1) * step - 1, 1000, 1, 100, 50, 0] for i in range(12)]

    monkeypatch.setattr(adapter, "get_candles", fake_candles)
    client = TestClient(app)
    response = client.get("/markets/BTCUSDT/analysis?intervals=5m,15m,1h")
    assert response.status_code == 200
    body = response.json()
    assert body["symbol"] == "BTCUSDT"
    assert set(body["timeframes"]) == {"5m", "15m", "1h"}
    assert body["overall_trend"] == "BULLISH"
