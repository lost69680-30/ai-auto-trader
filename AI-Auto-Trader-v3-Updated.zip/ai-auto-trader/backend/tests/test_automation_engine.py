from backend.app.domain.market import Candle
from backend.app.services.automation_engine import AccountSnapshot, AutomationEngine
from backend.app.services.execution import ExecutionService
from backend.app.services.risk_engine import RiskEngine, RiskPolicy


def rows(values):
    import time
    start = int(time.time() * 1000) - 11 * 900_000
    return [[start + i * 900_000, v, v + 1, v - 1, v, 1000, start + (i + 1) * 900_000 - 1, 1000, 1, 100, 50, 0] for i, v in enumerate(values)]


class FakeAdapter:
    def __init__(self): self.orders = []
    def get_candles(self, symbol, interval, limit=200): return rows([100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111])
    def place_order(self, intent): self.orders.append(intent); return {"status": "NEW", "orderId": str(len(self.orders))}
    def get_order_status(self, client_order_id, symbol): return {"status": "NEW", "orderId": "1"}


def test_automation_engine_does_not_execute_when_risk_blocks():
    adapter = FakeAdapter()
    engine = AutomationEngine(adapter, ExecutionService(adapter), RiskEngine(RiskPolicy()))
    result = engine.run_cycle("BTCUSDT", AccountSnapshot(equity=10_000, daily_realized_loss=-300, drawdown=0.01, open_positions=0), emergency_stop=False)
    assert result.status == "BLOCKED"
    assert adapter.orders == []


def test_automation_engine_creates_execution_only_after_risk_approval():
    adapter = FakeAdapter()
    engine = AutomationEngine(adapter, ExecutionService(adapter), RiskEngine(RiskPolicy()))
    result = engine.run_cycle("BTCUSDT", AccountSnapshot(equity=10_000, daily_realized_loss=0, drawdown=0, open_positions=0), emergency_stop=False)
    assert result.status == "EXECUTED"
    assert len(adapter.orders) == 1
