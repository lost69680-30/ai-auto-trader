# AI Auto Trader Runbook

## Local backend

```bash
python -m pip install -e ".[test]"
uvicorn backend.app.main:app --reload --port 8000
```

The default profile is Binance Spot Testnet. Do not put Binance secrets in the Android application, repository, or logs.

## Android

The Android project targets current stable AGP/Kotlin/Compose tooling. The local container used for this assembly has Java and Kotlin but no Android SDK, so APK compilation is delegated to the GitHub Actions Android workflow.

The workflow installs the Android 37 platform and Build Tools 36.0.0, builds the debug APK, and publishes it as a workflow artifact.

## Testnet credentials

Set `BINANCE_API_KEY` and `BINANCE_API_SECRET` only as backend/CI secrets. Keep withdrawals disabled on the exchange key. Start with read-only/public market tests and then a controlled Testnet order smoke test.

## Safety states

- `TESTNET` is the default environment.
- `LIVE_TRADING_ENABLED=false` is the safe default.
- Emergency stop disables automation on the backend.
- Unknown order responses require reconciliation before any retry.
