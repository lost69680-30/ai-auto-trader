# AI Auto Trader Build Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build an analysis-first autonomous trading platform with a Python/FastAPI backend, market intelligence/data pipeline, deterministic risk and execution controls, Binance Spot Testnet adapter, and Kotlin/Jetpack Compose Android control app.

**Architecture:** A modular monorepo separates pure market-analysis/risk domain logic from exchange I/O and Android presentation. The backend is authoritative for credentials, decisions, risk, execution, persistence, and audit; Android is a secure control/telemetry client. The system defaults to Testnet and supports a generic broker-adapter interface for future forex integration.

**Tech Stack:** Python 3.12+, FastAPI, Pydantic, SQLAlchemy, PostgreSQL-compatible persistence (SQLite for local tests), httpx, pytest; Kotlin 2.4.20, Android Gradle Plugin 9.4.0, Gradle 9.6, Jetpack Compose BOM 2026.09.00, Material 3, ViewModel/StateFlow, Retrofit/OkHttp; GitHub Actions for CI/build artifact generation.

**Spec:** docs/superpowers/specs/2026-09-27-ai-auto-trader-design.md

## Global Constraints
- Testnet is the default environment.
- Live execution is disabled by default.
- Android never receives exchange private keys.
- AI never directly submits an exchange order.
- Every order requires a persisted risk decision before submission.
- Unknown exchange responses trigger reconciliation before retry.
- Every active position has an exit-protection plan.
- A valid outcome is `NO_TRADE` when evidence or risk is insufficient.
- Historical model/strategy changes require out-of-sample and walk-forward validation before promotion.

## Review Focus
- Stale/invalid market data must block automated decisions.
- Partial/unknown exchange fills must reconcile without duplicate orders.
- Risk limits must survive backend restart and reconnect.
- AI-proposed quantities must be ignored; sizing comes from deterministic risk logic.
- Strategy degradation must pause automation rather than increase risk.

---

### Task 1: Repository foundation and backend test harness

**Files:**
- Create: `pyproject.toml`, `backend/app/__init__.py`, `backend/app/config.py`, `backend/tests/test_smoke.py`, `.gitignore`, `README.md`

**Interfaces:**
- Produces `Settings` from `backend.app.config.settings` and a pytest-able backend package for later tasks.

- [ ] **Step 1: Write failing smoke test**

```python
def test_settings_default_to_testnet():
    from backend.app.config import Settings
    assert Settings().environment == "testnet"
```

- [ ] **Step 2: Run** `pytest backend/tests/test_smoke.py -q` and verify it fails because `backend.app.config` is missing.
- [ ] **Step 3: Implement minimal settings/config and package structure.**
- [ ] **Step 4: Run** `pytest backend/tests/test_smoke.py -q` and verify PASS.
- [ ] **Step 5: Commit** `chore: scaffold backend foundation`.

### Task 2: Candle intelligence and market analysis

**Files:**
- Create: `backend/app/domain/market.py`, `backend/app/services/market_analysis.py`, `backend/tests/test_market_analysis.py`

**Interfaces:**
- `Candle` dataclass/model: timestamp, open, high, low, close, volume.
- `MarketAssessment` contains regime, features, risk_factors, data_quality, opportunity_state, and reason_codes.
- `analyze_market(candles: list[Candle], timeframe: str) -> MarketAssessment`.

- [ ] **Step 1: Write failing tests** for candle range/body/wicks, ATR, momentum, volatility, relative volume, multi-candle trend, and insufficient-data behavior.
- [ ] **Step 2: Run** `pytest backend/tests/test_market_analysis.py -q` and verify expected failures for missing analysis functions.
- [ ] **Step 3: Implement deterministic analysis functions with no external AI dependency.**
- [ ] **Step 4: Run** the focused tests and verify PASS.
- [ ] **Step 5: Commit** `feat: add candle intelligence analysis`.

### Task 3: Data-quality and regime/risk assessment

**Files:**
- Create: `backend/app/services/data_quality.py`, `backend/app/services/risk_assessment.py`, `backend/tests/test_data_quality.py`, `backend/tests/test_risk_assessment.py`

**Interfaces:**
- `assess_data_quality(candles) -> DataQualityReport`.
- `assess_risk(market_assessment, account_state, policy) -> RiskAssessment`.
- Risk assessment returns explicit block reasons.

- [ ] **Step 1: Write failing tests** for stale timestamps, duplicates, out-of-order candles, missing intervals, high volatility, high spread, insufficient liquidity, and drawdown limits.
- [ ] **Step 2: Run focused tests and verify expected failures.**
- [ ] **Step 3: Implement deterministic data-quality and risk scoring/gates.**
- [ ] **Step 4: Run focused tests and verify PASS.**
- [ ] **Step 5: Commit** `feat: add market risk and data quality gates`.

### Task 4: Strategy engine, backtesting, and strategy health

**Files:**
- Create: `backend/app/domain/strategy.py`, `backend/app/services/strategy_engine.py`, `backend/app/services/backtesting.py`, `backend/app/services/strategy_health.py`, `backend/tests/test_strategy_engine.py`, `backend/tests/test_backtesting.py`, `backend/tests/test_strategy_health.py`

**Interfaces:**
- `StrategySignal` with side, confidence, reason_codes, stop_policy, take_profit_policy, expiry.
- `evaluate_strategy(market_assessment) -> StrategySignal`.
- `backtest(strategy, candles, costs) -> BacktestResult`.
- `evaluate_strategy_health(expected, observed) -> StrategyHealth`.

- [ ] **Step 1: Write failing tests** for baseline trend/momentum strategy, fee/slippage-aware backtest, no-lookahead, out-of-sample split, and automatic degradation/pause.
- [ ] **Step 2: Run and verify expected failures.**
- [ ] **Step 3: Implement baseline strategy, backtest engine, and health monitor.**
- [ ] **Step 4: Run focused tests and verify PASS.**
- [ ] **Step 5: Commit** `feat: add strategy lab and health monitoring`.

### Task 5: Risk engine and execution safety

**Files:**
- Create: `backend/app/domain/risk.py`, `backend/app/services/risk_engine.py`, `backend/app/services/execution.py`, `backend/tests/test_risk_engine.py`, `backend/tests/test_execution.py`

**Interfaces:**
- `approve_trade(signal, assessment, account, policy) -> RiskDecision`.
- `ExecutionIntent` persisted before submission.
- `ExecutionService.submit(intent)` validates client order idempotency and delegates to adapter.

- [ ] **Step 1: Write failing tests** for sizing, max risk/trade, max positions, daily loss, drawdown, cooldown, emergency stop, protected-exit requirement, and unknown-response reconciliation.
- [ ] **Step 2: Run and verify expected failures.**
- [ ] **Step 3: Implement deterministic risk engine and execution workflow.**
- [ ] **Step 4: Run focused tests and verify PASS.**
- [ ] **Step 5: Commit** `feat: add deterministic risk and execution controls`.

### Task 6: Binance Spot Testnet adapter and persistence/API

**Files:**
- Create: `backend/app/adapters/binance_testnet.py`, `backend/app/db.py`, `backend/app/models.py`, `backend/app/main.py`, `backend/tests/test_binance_adapter.py`, `backend/tests/test_api.py`

**Interfaces:**
- `BinanceTestnetAdapter.get_exchange_info()`.
- `get_account_summary()`.
- `get_candles(symbol, interval, limit)`.
- `place_order(intent)` and `get_order_status(...)`.
- FastAPI endpoints from spec, including health, markets, candles, account, orders, positions, performance, risk, automation, and WebSocket.

- [ ] **Step 1: Write failing tests** for signed-request construction, Testnet base URL, secret isolation, API health, and basic market/analysis endpoints.
- [ ] **Step 2: Run focused tests and verify expected failures.**
- [ ] **Step 3: Implement adapter, persistence, FastAPI routing, and WebSocket event skeleton.**
- [ ] **Step 4: Run backend suite and verify PASS.**
- [ ] **Step 5: Commit** `feat: add Testnet adapter and backend API`.

### Task 7: Android application

**Files:**
- Create: `android/settings.gradle.kts`, `android/build.gradle.kts`, `android/gradle.properties`, `android/app/build.gradle.kts`, `android/app/src/main/AndroidManifest.xml`, `android/app/src/main/java/com/aiautotrader/MainActivity.kt`, `android/app/src/main/java/com/aiautotrader/ui/*`
- Create: `android/src/test/*`, `android/app/src/androidTest/*`

**Interfaces:**
- `MarketUiState`, `RiskUiState`, `AutomationUiState` driven by backend REST/WebSocket data.
- Screens: overview, market analysis, positions, orders, analytics, risk center, audit/activity, settings.

- [ ] **Step 1: Write failing ViewModel/state tests** for Testnet badge visibility, risk-block state, emergency-stop state, and market-analysis rendering.
- [ ] **Step 2: Run tests through the configured Android build when an SDK/Gradle environment is available; otherwise record the environment blocker and rely on CI build verification.**
- [ ] **Step 3: Implement Compose UI and API/WebSocket client.**
- [ ] **Step 4: Run available Android unit/UI tests and verify PASS.**
- [ ] **Step 5: Commit** `feat: add Android trading intelligence app`.

### Task 8: CI/CD, security checks, and verification workflow

**Files:**
- Create: `.github/workflows/backend.yml`, `.github/workflows/android.yml`, `.github/workflows/security.yml`, `docker-compose.yml`, `.env.example`, `docs/runbook.md`

**Interfaces:**
- CI builds backend and Android independently, runs tests, rejects committed secrets, and publishes APK as workflow artifact on successful release builds.

- [ ] **Step 1: Write validation tests/scripts** for secret absence, Testnet default, and API health.
- [ ] **Step 2: Verify scripts fail before CI configuration where appropriate.**
- [ ] **Step 3: Add GitHub Actions workflows and local Docker/dev configuration.**
- [ ] **Step 4: Run local validation and backend suite; verify PASS.**
- [ ] **Step 5: Commit** `ci: add build security and release workflows`.

### Task 9: Final integration and release package

**Files:**
- Create: `scripts/verify_all.sh`, `release/README.md`, `docs/testnet-checklist.md`

**Interfaces:**
- `scripts/verify_all.sh` runs backend tests, checks Android project structure, validates configuration safety, and reports build-environment limitations clearly.

- [ ] **Step 1: Write failing integration checks** for required files, Testnet defaults, API health, and no live credentials.
- [ ] **Step 2: Run and verify expected failures for missing integration pieces.**
- [ ] **Step 3: Implement integration wiring and release documentation.**
- [ ] **Step 4: Run full verification and verify all available checks PASS.**
- [ ] **Step 5: Commit** `release: assemble AI Auto Trader Testnet package`.
