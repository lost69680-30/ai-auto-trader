# AI Auto Trader — Connected Android + Backend Design Specification

**Status:** Approved design baseline
**Date:** 2026-09-27

## Goal
Build a connected Android AI Auto Trader platform that can autonomously evaluate configured crypto and forex markets, enforce deterministic risk controls, execute only through approved broker/exchange adapters, maintain an auditable trade ledger, and expose the entire operating state through a modern Android dashboard.

## Product boundary
- Initial execution environment: Binance Spot Testnet.
- Initial crypto execution: Spot only.
- Forex support: broker-adapter interface and paper/simulation mode first; a concrete live broker is not enabled until its credentials, instrument rules, and test environment are configured.
- Live-money execution is disabled by default and requires an explicit configuration change outside the shipped Testnet profile.
- API secrets remain server-side; the Android client never receives exchange private keys.

## Product intelligence priority
The product is analysis-first: **market data → analysis → risk assessment → opportunity detection → decision → execution**. Trading is downstream of evidence, not the primary product objective. A valid system state is `NO_TRADE` when evidence quality or risk conditions are insufficient.

### Analysis-first subsystems
- **Candle intelligence** — candle body/wick/range, ATR, momentum, volatility, relative volume, structure, breakouts, rejections, consolidation, support/resistance, and multi-timeframe relationships.
- **Market regime engine** — trending, ranging, breakout, high-volatility, low-volatility, and unstable states with measurable features and confidence.
- **Risk assessment engine** — volatility, liquidity, spread, slippage, concentration, drawdown, regime uncertainty, data quality, and execution-health factors.
- **Historical research store** — candles/features/signals/risk states/outcomes captured as structured records for long-term analysis.
- **Data quality monitor** — stale data, missing/duplicate candles, timestamp anomalies, feed gaps, inconsistent snapshots, and exchange-health state.
- **Strategy Lab** — backtest, out-of-sample, walk-forward, stress test, paper trading, and Testnet promotion gates.
- **Strategy health monitor** — compares current live/Testnet behavior with validated expectations and can degrade/pause a strategy automatically.

## Architecture
The system is a modular monorepo with a Python/FastAPI backend and Kotlin/Jetpack Compose Android application. The backend owns authentication, market data, strategy evaluation, risk decisions, execution, reconciliation, persistence, background jobs, and audit logs. The Android application is a control surface and telemetry client, not a trading-secret holder.

### Core modules
0. **Market Intelligence & Analytics** — the primary intelligence layer described above; execution consumes its outputs but does not define them.
1. **Backend API** — FastAPI REST + WebSocket endpoints.
2. **Auth service** — user/session authentication and authorization.
3. **Market data service** — normalized candles, tick data, indicators, and connection health.
4. **Strategy engine** — deterministic strategy components plus an AI analysis layer that may score/route strategies but cannot bypass risk rules.
5. **Risk engine** — max risk/trade, max concurrent positions, daily loss, drawdown, volatility guard, cooldowns, exposure caps, and emergency stop.
6. **Execution engine** — idempotent order submission, validation against symbol rules, status reconciliation, retry policy, and unknown-execution handling.
7. **Broker adapters** — Binance Spot Testnet first; generic Forex adapter contract for later broker integration.
8. **Position manager** — open positions, realized/unrealized P&L, SL/TP state, trailing protection, and reconciliation.
9. **Ledger/analytics** — append-only trade/order/risk events plus performance metrics.
10. **Android app** — dashboard, charts, orders, positions, strategy control, analytics, risk center, and emergency stop.

## Data flow
Market feed → normalization → feature/indicator computation → strategy evaluation → AI strategy score → deterministic risk gate → execution plan → exchange/broker adapter → order acknowledgement → reconciliation → position/ledger update → WebSocket event → Android UI.

No AI component can directly place an order. Every trade must pass the deterministic risk gate and execution policy.

## Analysis and decision model
The analysis pipeline produces a structured `MarketAssessment` for each symbol/timeframe set. The assessment contains:
- market regime
- trend/momentum/volatility features
- liquidity/spread/slippage estimates when available
- multi-timeframe alignment
- data-quality state
- risk factors and overall risk state
- opportunity state (`NONE`, `WATCH`, `CANDIDATE`, `APPROVED`)
- reason codes and feature provenance

No single candle pattern is treated as a guaranteed predictor. Historical relationships must be measured out-of-sample and monitored for degradation.

## Strategy model
Strategies implement a shared interface:
- `evaluate(market_snapshot) -> StrategySignal`
- signal contains side, confidence, reason codes, stop distance, take-profit policy, and expiry.

The initial built-in strategy pack will be conservative and testable:
- trend/momentum baseline
- volatility filter
- multi-timeframe confirmation
- spread/liquidity filter

The AI layer is an advisory/routing layer that can rank configured strategies and explain the selected setup. It cannot invent order quantities or override risk limits.

## Risk model
The risk engine is authoritative. Default Testnet profile:
- risk per trade: configurable, default 0.5% of risk capital
- max open positions: configurable, default 3
- maximum daily realized loss: configurable, default 2%
- maximum equity drawdown guard: configurable, default 5%
- cooldown after a configurable loss streak
- no new entries during emergency stop
- every position has a protected exit plan before it is considered active

All limits are server-side and are re-checked immediately before execution.

## Order safety
- Generate a unique client order ID for every submission.
- Persist an execution intent before submitting an order.
- On timeout/unknown response, query order status before retrying.
- Reconcile open orders and positions periodically.
- Validate price/quantity/step-size/notional rules from exchange metadata before submission.
- Keep an immutable audit trail of intent, risk decision, submission, acknowledgement, fill, cancellation, and recovery events.

## Binance integration
Use Binance's officially documented interfaces only. Current Binance Spot documentation supports REST and WebSocket interfaces, signed user-data endpoints, and API-key permissions such as `TRADE` and `USER_DATA`. Signed requests require a current timestamp and authentication. The implementation will therefore isolate signing/authentication inside the Binance adapter and use server-side secrets only. Binance documents a dedicated Spot Testnet environment and Spot Testnet WebSocket streams; Testnet connections should be treated as reconnectable infrastructure rather than permanent connections.

## Android application
Screens:
- Sign in
- Overview/dashboard
- Market watch
- Chart + analysis
- Positions
- Orders
- Strategy control
- Risk center
- Performance/analytics
- Activity/audit log
- Settings / connection status
- Emergency stop confirmation + status

UI principles:
- dark trading-oriented visual system
- clear green/red/neutral state semantics with accessible secondary cues
- no fake live values in production/Testnet mode
- explicit Testnet badge throughout the app
- connection, strategy, and emergency-stop state always visible

## Persistence
PostgreSQL-compatible database schema with:
- users/sessions
- accounts/broker connections (secret references only)
- instruments
- market snapshots/candles metadata
- strategies/strategy versions
- risk policies
- orders/order events
- positions/position events
- trades
- P&L snapshots
- audit events

Secrets are referenced by secret identifiers or encrypted server-side storage; raw secrets are never persisted in ordinary application tables or returned through API responses.

## API contracts
REST for command/query operations and WebSocket for live state.

Minimum endpoints:
- `POST /auth/login`
- `GET /health`
- `GET /account/summary`
- `GET /markets`
- `GET /markets/{symbol}/candles`
- `GET /positions`
- `GET /orders`
- `GET /performance`
- `GET /risk`
- `POST /risk/emergency-stop`
- `POST /risk/emergency-resume`
- `POST /automation/start`
- `POST /automation/stop`
- `GET /automation/status`
- `WS /ws`

## Background jobs
- market stream supervisor
- strategy evaluation scheduler
- order reconciliation
- position reconciliation
- SL/TP supervisor
- performance aggregation
- health/heartbeat monitor
- stale-connection recovery

## Data-analysis testing strategy
- Deterministic feature tests for candle math, ATR, volatility, momentum, volume normalization, regime classification, and risk scoring.
- Golden-data fixtures for known candle sequences.
- Data-quality tests for missing, duplicate, stale, and out-of-order data.
- Backtest validation tests for fee/slippage handling and look-ahead prevention.
- Strategy-health tests for degradation and automatic pause conditions.

## Testing strategy
### Backend
- TDD for domain logic and risk rules.
- unit tests for signal, sizing, SL/TP, drawdown, cooldown, emergency stop, idempotency, order reconciliation, and adapter signing.
- integration tests for API/database boundaries.
- Testnet smoke tests when credentials are supplied.

### Android
- unit tests for ViewModels and state reducers.
- Compose UI tests for primary flows.
- emulator QA using adb, UI-tree inspection, screenshots, and logcat.

### End-to-end
1. login
2. connect to backend
3. load Testnet account summary
4. receive live market data
5. start automation
6. generate a paper/simulated signal
7. pass/fail risk gate
8. submit Testnet order only when explicitly enabled
9. reconcile order
10. create/update position
11. manage SL/TP
12. emergency stop
13. verify recovery and audit trail

## CI/CD
- backend lint + type checking + unit/integration tests
- Android compile + unit/UI tests
- security checks for secrets
- build artifact generation
- release build only from a protected workflow

## Operational safety
- Testnet is the default environment.
- Live trading configuration is fail-closed.
- No credentials are hardcoded.
- No exchange order is submitted without a persisted risk decision.
- Unknown execution status triggers reconciliation, not blind retry.
- Emergency stop is independent of the AI strategy layer.

## Success criteria
The first shippable milestone is a working Testnet system that can be installed on Android, authenticate to the backend, display real Testnet market/account state, run the deterministic strategy/risk pipeline, submit and reconcile Testnet Spot orders when enabled, enforce SL/TP and emergency-stop behavior, recover from transient failures, and retain a complete audit trail.

## Current evidence / external references
- Binance documents REST endpoints, authentication, timestamp/signature requirements, API-key permissions, and official supported interfaces. See the current Binance Developer Documentation.
- Binance documents Spot Testnet terms and dedicated Spot Testnet WebSocket streams.
