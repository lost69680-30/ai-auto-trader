# Binance Spot Testnet Checklist

- [ ] Create a Binance Spot Testnet API key.
- [ ] Keep withdrawals disabled.
- [ ] Store key/secret only in backend environment or CI secrets.
- [ ] Confirm `APP_ENV=testnet` and `LIVE_TRADING_ENABLED=false`.
- [ ] Verify public market data first.
- [ ] Verify authenticated account summary.
- [ ] Verify a single small Testnet market order.
- [ ] Verify order reconciliation after the response.
- [ ] Verify duplicate client order IDs cannot double-submit.
- [ ] Verify protected exit policy before automation.
- [ ] Verify emergency stop prevents new entries.
- [ ] Verify reconnect/reconciliation after backend restart.
- [ ] Verify Android dashboard reflects backend state.
- [ ] Keep live execution disabled until the entire Testnet checklist passes.
