package com.aiautotrader

import com.aiautotrader.ui.CandlePoint
import com.aiautotrader.ui.TraderApi
import com.aiautotrader.ui.TraderViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.json.JSONObject
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Assert.assertTrue

class TraderViewModelTest {
    private val dispatcher = StandardTestDispatcher()

    @Before fun setup() { Dispatchers.setMain(dispatcher) }
    @After fun tearDown() { Dispatchers.resetMain() }

    @Test fun emergencyStopIsReflectedInState() = runTest(dispatcher) {
        val api = FakeApi()
        val vm = TraderViewModel(api)
        vm.emergencyStop()
        dispatcher.scheduler.advanceUntilIdle()
        assertTrue(api.stopCalled)
    }

    private class FakeApi : TraderApi {
        var stopCalled = false
        override suspend fun health() = JSONObject("{\"status\":\"ok\",\"automation_running\":false,\"emergency_stop\":true}")
        override suspend fun risk() = JSONObject("{\"risk_level\":\"HIGH\",\"reasons\":[\"TEST\"]}")
        override suspend fun analysis(symbol: String, intervals: String) = JSONObject("{\"overall_trend\":\"BULLISH\",\"evidence_state\":\"WATCH\",\"risk_level\":\"MEDIUM\",\"timeframes\":{}}")
        override suspend fun candles(symbol: String, interval: String, limit: Int) = listOf(CandlePoint(1, 100.0), CandlePoint(2, 101.0))
        override suspend fun automationStart() = JSONObject()
        override suspend fun automationStop() = JSONObject()
        override suspend fun emergencyStop(): JSONObject { stopCalled = true; return JSONObject("{\"emergency_stop\":true}") }
        override suspend fun emergencyResume() = JSONObject()
    }
}
