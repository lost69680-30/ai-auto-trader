package com.aiautotrader.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TraderViewModel(private val api: TraderApi) : ViewModel() {
    private val _state = MutableStateFlow(TraderUiState(loading = true))
    val state: StateFlow<TraderUiState> = _state.asStateFlow()

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            _state.value = _state.value.copy(loading = true, error = null)
            runCatching {
                val health = api.health()
                val risk = api.risk()
                val analysis = api.analysis()
                val candles = api.candles()
                val last = candles.lastOrNull()?.close
                val timeframes = analysis.optJSONObject("timeframes")
                val mid = timeframes?.optJSONObject("15m")
                val features = mid?.optJSONObject("features")
                val running = health.optBoolean("automation_running", false)
                val emergency = health.optBoolean("emergency_stop", false)
                MarketUi(
                    price = last,
                    regime = mid?.optString("regime", "WAITING") ?: "WAITING",
                    trend = analysis.optString("overall_trend", "WAITING"),
                    momentum = features?.optDouble("momentum", Double.NaN)?.takeUnless { it.isNaN() }?.let { String.format("%.2f%%", it * 100) } ?: "WAITING",
                    volatility = features?.optDouble("volatility", Double.NaN)?.takeUnless { it.isNaN() }?.let { String.format("%.2f%%", it * 100) } ?: "WAITING",
                    liquidity = features?.optDouble("relative_volume", Double.NaN)?.takeUnless { it.isNaN() }?.let { String.format("%.2fx", it) } ?: "WAITING",
                    riskLevel = analysis.optString("risk_level", risk.optString("risk_level", "UNKNOWN")),
                    opportunity = analysis.optString("evidence_state", "NO DATA"),
                    evidenceState = analysis.optString("evidence_state", "NO DATA"),
                    candles = candles,
                    connected = health.optString("status") == "ok",
                ) to (running to emergency)
            }.onSuccess { (market, controls) ->
                _state.value = TraderUiState(market = market, automationRunning = controls.first, emergencyStop = controls.second)
            }.onFailure { error ->
                _state.value = _state.value.copy(loading = false, error = error.message ?: "Connection failed")
            }
        }
    }

    fun emergencyStop() = command { api.emergencyStop() }
    fun emergencyResume() = command { api.emergencyResume() }
    fun toggleAutomation() = command { if (_state.value.automationRunning) api.automationStop() else api.automationStart() }

    private fun command(action: suspend () -> org.json.JSONObject) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { action() }
                .onSuccess { refresh() }
                .onFailure { _state.value = _state.value.copy(error = it.message ?: "Command failed") }
        }
    }
}
