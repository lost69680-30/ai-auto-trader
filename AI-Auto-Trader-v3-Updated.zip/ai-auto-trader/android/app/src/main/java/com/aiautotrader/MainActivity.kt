package com.aiautotrader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aiautotrader.ui.HttpTraderApi
import com.aiautotrader.ui.TraderViewModel
import androidx.lifecycle.ViewModelProvider

private val Bg = Color(0xFF081015)
private val CardBg = Color(0xFF101A20)
private val Accent = Color(0xFF38E8A1)
private val Warning = Color(0xFFFFC857)
private val Danger = Color(0xFFFF5C73)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val api = HttpTraderApi("http://10.0.2.2:8000")
        setContent {
            val vm: TraderViewModel = viewModel(factory = object : ViewModelProvider.Factory {
                override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T = TraderViewModel(api) as T
            })
            TraderApp(vm)
        }
    }
}

@Composable
private fun TraderApp(vm: TraderViewModel) {
    val state by vm.state.collectAsState()
    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("MARKET INTELLIGENCE", style = MaterialTheme.typography.titleLarge, color = Color.White)
                    Text("Analysis-first autonomous trader", color = Color(0xFF90A4AE))
                }
                Text("TESTNET", color = Accent, modifier = Modifier.background(Accent.copy(alpha = .12f), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp))
            }
            RiskCard(state.market.riskLevel, state.market.opportunity)
            MarketCard(state.market)
            if (state.error != null) Text("${state.error}", color = Danger)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { vm.refresh() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = CardBg)) { Text("Refresh") }
                Button(onClick = { vm.toggleAutomation() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (state.automationRunning) Warning else Accent)) { Text(if (state.automationRunning) "Stop Automation" else "Start Automation", color = Color.Black) }
            }
            Button(onClick = { if (!state.emergencyStop) vm.emergencyStop() else vm.emergencyResume() }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (state.emergencyStop) Warning else Danger)) {
                Text(if (state.emergencyStop) "Resume After Emergency Stop" else "EMERGENCY STOP", color = Color.White)
            }
            Spacer(Modifier.height(4.dp))
            Text("Trading is downstream of analysis. A NO TRADE decision is valid when evidence or risk is insufficient.", color = Color(0xFF90A4AE))
        }
    }
}

@Composable
private fun RiskCard(risk: String, opportunity: String) {
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(18.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("RISK ASSESSMENT", color = Color(0xFF90A4AE))
                Text(risk, style = MaterialTheme.typography.headlineMedium, color = if (risk == "HIGH") Danger else if (risk == "MEDIUM") Warning else Color.White)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("OPPORTUNITY", color = Color(0xFF90A4AE))
                Text(opportunity, color = Accent)
            }
        }
    }
}

@Composable
private fun MarketCard(market: com.aiautotrader.ui.MarketUi) {
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(18.dp)) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(market.symbol, color = Color.White, style = MaterialTheme.typography.titleLarge)
                Text(market.price?.let { "${"%.2f".format(it)}" } ?: "No live data", color = Color.White)
            }
            if (market.candles.size >= 2) PriceChart(market.candles.map { it.close }) else Text("Connect to the backend to load live market candles.", color = Color(0xFF90A4AE))
            MetricsRow("Regime", market.regime, "Trend", market.trend)
            MetricsRow("Momentum", market.momentum, "Volatility", market.volatility)
            MetricsRow("Liquidity", market.liquidity, "Connection", if (market.connected) "ONLINE" else "OFFLINE")
        }
    }
}

@Composable
private fun MetricsRow(a: String, av: String, b: String, bv: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Row { Text("$a: ", color = Color(0xFF90A4AE)); Text(av, color = Color.White) }
        Row { Text("$b: ", color = Color(0xFF90A4AE)); Text(bv, color = Color.White) }
    }
}

@Composable
private fun PriceChart(values: List<Double>) {
    val max = values.maxOrNull() ?: 1.0
    val min = values.minOrNull() ?: 0.0
    Canvas(modifier = Modifier.fillMaxWidth().height(130.dp)) {
        val span = (max - min).coerceAtLeast(1e-9)
        val path = Path()
        values.forEachIndexed { index, value ->
            val x = size.width * index / (values.size - 1).coerceAtLeast(1)
            val y = size.height - ((value - min) / span * size.height).toFloat()
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color = Accent, strokeWidth = 4f)
        drawLine(Color(0xFF22323A), Offset(0f, size.height - 1), Offset(size.width, size.height - 1), 2f)
    }
}
