package com.aiautotrader.ui

data class CandlePoint(val timestamp: Long, val close: Double)

data class MarketUi(
    val symbol: String = "BTCUSDT",
    val price: Double? = null,
    val regime: String = "WAITING",
    val trend: String = "WAITING",
    val momentum: String = "WAITING",
    val volatility: String = "WAITING",
    val liquidity: String = "WAITING",
    val riskLevel: String = "UNKNOWN",
    val opportunity: String = "NO DATA",
    val evidenceState: String = "NO DATA",
    val candles: List<CandlePoint> = emptyList(),
    val connected: Boolean = false,
)

data class TraderUiState(
    val market: MarketUi = MarketUi(),
    val emergencyStop: Boolean = false,
    val automationRunning: Boolean = false,
    val loading: Boolean = false,
    val error: String? = null,
)
