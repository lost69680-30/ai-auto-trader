package com.aiautotrader.ui

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

interface TraderApi {
    suspend fun health(): JSONObject
    suspend fun candles(symbol: String = "BTCUSDT", interval: String = "15m", limit: Int = 100): List<CandlePoint>
    suspend fun analysis(symbol: String = "BTCUSDT", intervals: String = "5m,15m,1h"): JSONObject
    suspend fun risk(): JSONObject
    suspend fun automationStart(): JSONObject
    suspend fun automationStop(): JSONObject
    suspend fun emergencyStop(): JSONObject
    suspend fun emergencyResume(): JSONObject
}

class HttpTraderApi(private val baseUrl: String) : TraderApi {
    private val client = OkHttpClient()

    private fun get(path: String): JSONObject {
        val request = Request.Builder().url("$baseUrl$path").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            return JSONObject(response.body?.string().orEmpty())
        }
    }

    private fun post(path: String): JSONObject {
        val request = Request.Builder().url("$baseUrl$path").post(okhttp3.RequestBody.create(null, ByteArray(0))).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            return JSONObject(response.body?.string().orEmpty())
        }
    }

    override suspend fun health() = get("/health")
    override suspend fun analysis(symbol: String, intervals: String) = get("/markets/$symbol/analysis?intervals=$intervals")
    override suspend fun risk() = get("/risk")
    override suspend fun automationStart() = post("/automation/start")
    override suspend fun automationStop() = post("/automation/stop")
    override suspend fun emergencyStop() = post("/risk/emergency-stop")
    override suspend fun emergencyResume() = post("/risk/emergency-resume")

    override suspend fun candles(symbol: String, interval: String, limit: Int): List<CandlePoint> {
        val body = get("/markets/$symbol/candles?interval=$interval&limit=$limit")
        val rows = body.getJSONArray("candles")
        return buildList(rows.length()) {
            for (i in 0 until rows.length()) {
                val row = rows.getJSONArray(i)
                add(CandlePoint(row.getLong(0), row.getDouble(4)))
            }
        }
    }
}
