# Keep networking/data classes stable for reflection-free JSON handling.
