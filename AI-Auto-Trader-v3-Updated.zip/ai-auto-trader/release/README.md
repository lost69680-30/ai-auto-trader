# AI Auto Trader — Testnet Build Package

This package contains the assembled analysis-first Android + backend project.

## Verified in the assembly environment

- 34 backend tests passing.
- Backend Python compilation passing.
- FastAPI app imports successfully.
- GitHub Actions workflow YAML parses successfully.
- Safe Testnet defaults verified.
- No obvious private-key/AWS-key material found by the repository scan.
- Pure Kotlin UI model source compiles with `kotlinc`.

## Not verified locally

The container does not have the Android SDK or Gradle installed, so the complete Android APK compilation was not run locally. The repository includes a GitHub Actions workflow that installs Android API 37, Build Tools 36.0.0, Java 17 and Gradle 9.6, then runs the Android unit tests and produces the debug APK artifact.

## First Testnet setup

1. Configure backend Testnet credentials as environment/CI secrets.
2. Keep withdrawals disabled.
3. Start with public market-data checks.
4. Run authenticated account checks.
5. Run one controlled Testnet order and verify reconciliation.
6. Verify emergency-stop and restart/reconciliation behavior.

Live trading remains disabled in the default configuration.
