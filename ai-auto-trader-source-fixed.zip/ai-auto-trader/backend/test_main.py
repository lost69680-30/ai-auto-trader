from fastapi.testclient import TestClient
from main import app

c=TestClient(app)
def test_health():
    r=c.get('/health'); assert r.status_code==200; assert r.json()['ok'] is True

def test_automation_gate():
    r=c.post('/orders/validate',json={'symbol':'BTCUSDT','side':'BUY','quantity':0.001})
    assert r.status_code==409

def test_start_and_validate():
    assert c.post('/automation/start').status_code==200
    r=c.post('/orders/validate',json={'symbol':'BTCUSDT','side':'BUY','quantity':0.001})
    assert r.status_code==200 and r.json()['testnet_only'] is True
    c.post('/emergency-stop')
