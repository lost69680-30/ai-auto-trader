from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from enum import Enum
import os, hmac, hashlib, time
import httpx

app = FastAPI(title='AI Auto Trader Backend', version='0.1.0')

class Side(str, Enum):
    BUY='BUY'; SELL='SELL'

class OrderRequest(BaseModel):
    symbol: str = Field(pattern=r'^[A-Z0-9]{5,20}$')
    side: Side
    quantity: float = Field(gt=0)
    stop_loss_pct: float = Field(default=1.0, gt=0, lt=50)
    take_profit_pct: float = Field(default=2.0, gt=0, lt=100)

class RiskConfig(BaseModel):
    max_order_usdt: float = Field(default=25, gt=0)
    max_daily_loss_usdt: float = Field(default=10, gt=0)
    automation_enabled: bool = False

class BinanceTestnet:
    base = 'https://testnet.binance.vision'
    def __init__(self):
        self.key=os.getenv('BINANCE_TESTNET_API_KEY','')
        self.secret=os.getenv('BINANCE_TESTNET_API_SECRET','')
    async def account(self):
        if not self.key or not self.secret: return {'configured':False,'balances':[]}
        ts=int(time.time()*1000); q=f'timestamp={ts}'
        sig=hmac.new(self.secret.encode(),q.encode(),hashlib.sha256).hexdigest()
        async with httpx.AsyncClient(timeout=10) as c:
            r=await c.get(self.base+'/api/v3/account',params={'timestamp':ts,'signature':sig},headers={'X-MBX-APIKEY':self.key})
            r.raise_for_status(); return r.json()

broker=BinanceTestnet(); risk=RiskConfig()

@app.get('/health')
def health(): return {'ok':True,'environment':'BINANCE_TESTNET_ONLY'}

@app.get('/status')
def status(): return {'automation_enabled':risk.automation_enabled,'broker':'Binance Testnet','live_trading':False}

@app.post('/risk')
def set_risk(cfg: RiskConfig):
    global risk; risk=cfg; return risk

@app.post('/automation/start')
def start():
    risk.automation_enabled=True; return {'automation_enabled':True}

@app.post('/automation/stop')
def stop():
    risk.automation_enabled=False; return {'automation_enabled':False}

@app.post('/emergency-stop')
def emergency():
    risk.automation_enabled=False
    return {'stopped':True,'message':'Automation stopped; open positions require broker-side reconciliation.'}

@app.get('/account')
async def account():
    try: return await broker.account()
    except Exception as e: raise HTTPException(502, f'Binance Testnet error: {e}')

@app.post('/orders/validate')
def validate_order(o: OrderRequest):
    if not risk.automation_enabled: raise HTTPException(409,'Automation is stopped')
    # Quantity-only validation here; production execution must also validate price/notional/exchange filters.
    return {'accepted':True,'testnet_only':True,'order':o.model_dump()}
