package com.example.aiautotrader

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private var running=false
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(32,40,32,32) }
        val title=TextView(this).apply { text="AI Auto Trader"; textSize=28f; setTextColor(Color.WHITE) }
        val env=TextView(this).apply { text="BINANCE TESTNET • LIVE TRADING DISABLED"; textSize=14f; setTextColor(Color.YELLOW) }
        val status=TextView(this).apply { text="Automation: STOPPED"; textSize=20f; setPadding(0,32,0,32) }
        val start=Button(this).apply { text="START AUTOMATION" }
        val stop=Button(this).apply { text="EMERGENCY STOP" }
        start.setOnClickListener { running=true; status.text="Automation: RUNNING (TESTNET)" }
        stop.setOnClickListener { running=false; status.text="Automation: STOPPED" }
        root.addView(title); root.addView(env); root.addView(status); root.addView(start); root.addView(stop)
        setContentView(root)
    }
}
